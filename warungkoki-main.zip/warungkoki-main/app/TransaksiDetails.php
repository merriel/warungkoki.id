<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransaksiDetails extends Model
{
    protected $table = 'transaction_details';
    protected $fillable = [''];
    protected $primaryKey = 'id';
}
