<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SendNotif extends Model
{
    protected $table = 'notif';
    protected $fillable = [''];
    protected $primaryKey = 'id';
}
